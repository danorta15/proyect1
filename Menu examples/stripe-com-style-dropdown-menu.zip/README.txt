A Pen created at CodePen.io. You can find this one at https://codepen.io/ariona/pen/pENkXW.

 Recently Stripe.com Redesign it site, and the primary menu interaction really grab my attention. So here is the simple version of it. Hope you love it guys :)