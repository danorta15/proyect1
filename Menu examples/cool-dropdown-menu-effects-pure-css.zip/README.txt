A Pen created at CodePen.io. You can find this one at https://codepen.io/mrspok407/pen/VjBGyp.

 But pretty useless in real world :)