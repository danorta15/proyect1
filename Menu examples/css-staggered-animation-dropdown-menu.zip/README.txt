A Pen created at CodePen.io. You can find this one at https://codepen.io/CodeBoomer/pen/pbONgz.

 Watch me code it on YouTube: https://youtu.be/OKxASY7ABfs

This is a simple example of applying an animation delay to each child of a basic horizontal dropdown navigation menu.

Rather than applying the delay in CSS/SASS files based on nth-child(), we inject the delay via JQuery on document ready. This pattern can be used in a render function for Meteor or within Angular/React.

This could be done at mouseenter(), but there could be a javascript delay in relation to instant CSS hover. By having it in the page render, it ensures it up to date whenever the user hovers.

The function simply counts the number of children in the dropdown menu and applies a delay based on it's index value within the loop. If you have dropdown headers, dividers or links, you'll need to update it to traverse the DOM.

Easiest way is by console.log(index) within the each funciton to ensure it's counting the children properly.